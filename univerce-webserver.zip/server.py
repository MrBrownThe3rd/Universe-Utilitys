import socket
import os

def start_server():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    # Use the PORT environment variable provided by Replit
    port = int(os.getenv("PORT", 12345))
    server_socket.bind(('0.0.0.0', port))
    server_socket.listen(5)
    print(f"Server listening on port {port}")

    while True:
        client_socket, address = server_socket.accept()
        print(f"Connection from {address}")

        while True:
            data = client_socket.recv(1024)
            if not data:
                break
            print(f"Received: {data.decode()}")
            client_socket.sendall(data)

        client_socket.close()
        print(f"Connection with {address} closed")

if __name__ == "__main__":
    start_server()