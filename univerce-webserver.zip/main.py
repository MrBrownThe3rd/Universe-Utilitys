from flask import Flask, request, jsonify, render_template, redirect, url_for
import asyncio
import websockets
import server

app = Flask(__name__)



@app.route('/')
def home():
    return redirect(url_for('home2'))


@app.route('/home/Universe/TermOfService')
def home_universe_TermOfService():
    return render_template('terms.html')


@app.route('/home')
def home2():
    return render_template('home.html')



if __name__ == '__main__':
    server.start_server()
    app.run(host='0.0.0.0', port=5000)
